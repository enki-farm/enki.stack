{{/*
Expand the name of the chart.
*/}}
{{- define "activepieces.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "activepieces.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "activepieces.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "activepieces.labels" -}}
helm.sh/chart: {{ include "activepieces.chart" . }}
{{ include "activepieces.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "activepieces.selectorLabels" -}}
app.kubernetes.io/name: {{ include "activepieces.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "activepieces.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "activepieces.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "activepieces.workloadType" -}}
{{- $liveCluster := .Capabilities.APIVersions.Has "apps/v1/StatefulSet" }}
{{- $argoRollouts := .Capabilities.APIVersions.Has "argoproj.io/v1alpha1/Rollout" }}
{{- if .Values.workloadType }}
{{- .Values.workloadType }}
{{- else if and $liveCluster (not $argoRollouts) (not (lookup "v1" "Service" .Release.Namespace (printf "%s-preview" (include "activepieces.fullname" .)))) }}
{{- "statefulset" }}
{{- else }}
{{- "rollout" }}
{{- end }}
{{- end }}

{{- define "activepieces.cacheStorageClassName" -}}
{{- if .Values.persistence.storageClassName }}
{{- .Values.persistence.storageClassName }}
{{- else }}
{{- with lookup "apps/v1" "StatefulSet" .Release.Namespace (include "activepieces.fullname" .) }}
{{- range .spec.volumeClaimTemplates }}
{{- if eq .metadata.name "cache" }}
{{- .spec.storageClassName | default "" }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
